import { Component } from '@angular/core';

@Component({
  templateUrl: 'review-layout.component.html',
})
export class ReviewLayoutComponent {}
