export class changePasswordModel {
    PrevPassword:string;
    password:string;
  }
  
  