export class newReviewModel {
  assignmentid: string;
  ownerid: string;
  review: string;
  rate: string;
  category: string;
}
