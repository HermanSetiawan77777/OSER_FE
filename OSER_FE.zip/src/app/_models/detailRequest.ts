export class detailRequest {
  _id: string;
  status: string;
  AssignmentID: string;
  AssignmentName: string;
  OwnerID: string;
  OwnerName: string;
  OwnerEmail: string;
  UserID: string;
  UserName: string;
  Category: string;
  Duration: string;
  Price: string;
  StartPrice: string;
  OwnerDeal: string;
  UserDeal: string;
  UserEmail: string;
  statusNO: string;
}
