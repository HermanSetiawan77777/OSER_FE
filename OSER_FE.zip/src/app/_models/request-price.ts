export class RequestPrice{
  id: string;
  status: string;
  assignmentId: string;
  assignmentName: string;
  OwnerId: string;
  userId: string;
  userName: string;
  category: string;
  duration: string;
  price: string;
}
