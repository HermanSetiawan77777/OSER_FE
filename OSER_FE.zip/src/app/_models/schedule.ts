export class Schedule {
  message: string;
  id: string;
  status: string;
  review: string
  assignmentname: string;
  ownerid: string;
  ownername: string;
  userid: string;
  username: string;
  category: string;
  duration: number;
  price: string;
}
