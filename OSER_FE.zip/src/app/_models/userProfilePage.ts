export class UserProfilePage {
  id: string;
  username: string;
  password: string;
  gender: string;
  email: string;
  phone: string;
  projectCompleted: number;
  servicesCompleted: number;
  createdDate: string;
  Remarks: string;
  linkedIn: string;
  tanggallahir: string;
  audio: boolean;
  games: boolean;
  website: boolean;
  modelling: boolean;
}
