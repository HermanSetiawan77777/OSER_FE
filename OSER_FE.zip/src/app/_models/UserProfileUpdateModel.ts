export class UserProfileUpdateModel {
  username: string;
  password: string;
  phone: string;
  remarks: string;
  linkedin: string;
  workcat: string;
}
