export class UserProfile {
  id: string;
  username: string;
  email: string;
  phone: string;
  projectCompleted: string;
  servicesCompleted: string;
  createdDate: string;
  remarks: string;
}
