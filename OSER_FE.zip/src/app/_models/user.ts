﻿export class User {
  id: string;
  userid: string;
  username: string;
  email: string;
  phonenumber: number;
  password: string;
  retypepassword: string;
  code: string;
  validCode: string;
  remarks: string;
  token: string;
  message: any;
  linkedin: string;
  tanggallahir: string;
  workcat: string;
  gender: string;
  ktp: string;
}

