import { Component } from '@angular/core';

@Component({
  templateUrl: 'faq.html',
  styleUrls: ['faq.css', 'main.550dcf66.css'],
})

export class Faq {
}
