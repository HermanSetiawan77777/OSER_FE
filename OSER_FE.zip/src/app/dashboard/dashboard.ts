import { Component } from '@angular/core';

@Component({
  templateUrl: 'dashboard.html',
  styleUrls: ['main.550dcf66.css']
})

export class Dashboard{}
