import { Component } from '@angular/core';

@Component({ templateUrl: 'services-layout.component.html' })
export class ServicesLayoutComponent { }
