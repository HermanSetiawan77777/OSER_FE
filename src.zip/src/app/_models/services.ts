export class Services{
  message: string;
  id: string;
  ownerid: string;
  servicesname: string;
  category: string;
  duration: string;
  price: string;
  phone: number;
  email: string;
  remarks: string;
  file: File;
}

