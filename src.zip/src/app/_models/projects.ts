export class Projects {
  message: string;
  id: string;
  ownerid: string;
  category: string;
  projectname: string;
  name: string;
  projectid: string;
  price: string;
  deadline: string;
  duration: string;
  remarks: string;
  file: File;
}
