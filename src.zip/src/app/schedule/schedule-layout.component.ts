import { Component } from '@angular/core';

@Component({
  templateUrl: 'schedule-layout.component.html'
})

export class ScheduleLayoutComponent{

}
