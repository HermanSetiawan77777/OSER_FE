export const environment = {
  production: true,
  apiUrl: 'http://3.208.28.174:3003'
};
